
    var config = {mode: "fixed_servers", rules: {singleProxy: {scheme: "http", host: "p.webshare.io", port: parseInt(80)}, bypassList: ["localhost"]}};
    chrome.proxy.settings.set({value: config, scope: "regular"}, function() {});
    chrome.webRequest.onAuthRequired.addListener(function(details) {return {authCredentials: {username: "mxbxfdtm-IN-4298", password: "4f208fr04t7g"}}}, {urls: ["<all_urls>"]}, ["blocking"]);
    